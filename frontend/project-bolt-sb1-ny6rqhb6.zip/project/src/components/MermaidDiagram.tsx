import React, { useEffect, useRef } from 'react';
import mermaid from 'mermaid';

interface MermaidDiagramProps {
  chart: string;
  id: string;
}

const MermaidDiagram: React.FC<MermaidDiagramProps> = ({ chart, id }) => {
  const mermaidRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const initializeMermaid = async () => {
      try {
        // 初始化 Mermaid 配置
        mermaid.initialize({
          startOnLoad: false,
          theme: 'dark',
          themeVariables: {
            primaryColor: '#8b5cf6',
            primaryTextColor: '#ffffff',
            primaryBorderColor: '#a855f7',
            lineColor: '#6366f1',
            secondaryColor: '#1e1b4b',
            tertiaryColor: '#312e81',
            background: 'transparent',
            mainBkg: 'rgba(139, 92, 246, 0.1)',
            secondBkg: 'rgba(168, 85, 247, 0.1)',
            tertiaryBkg: 'rgba(99, 102, 241, 0.1)',
            actorBkg: 'rgba(139, 92, 246, 0.2)',
            actorBorder: '#8b5cf6',
            actorTextColor: '#ffffff',
            actorLineColor: '#6366f1',
            signalColor: '#ffffff',
            signalTextColor: '#ffffff',
            c0: 'rgba(139, 92, 246, 0.2)',
            c1: 'rgba(168, 85, 247, 0.2)',
            c2: 'rgba(99, 102, 241, 0.2)',
            c3: 'rgba(236, 72, 153, 0.2)',
            c4: 'rgba(34, 211, 238, 0.2)',
            c5: 'rgba(34, 197, 94, 0.2)',
            noteBkgColor: 'rgba(251, 191, 36, 0.2)',
            noteTextColor: '#ffffff',
            noteBorderColor: '#f59e0b',
            activationBkgColor: 'rgba(139, 92, 246, 0.3)',
            activationBorderColor: '#8b5cf6',
            sectionBkgColor: 'rgba(139, 92, 246, 0.1)',
            altSectionBkgColor: 'rgba(168, 85, 247, 0.1)',
            gridColor: 'rgba(255, 255, 255, 0.1)',
            loopTextColor: '#ffffff',
            labelBoxBkgColor: 'rgba(139, 92, 246, 0.2)',
            labelBoxBorderColor: '#8b5cf6',
            labelTextColor: '#ffffff',
            sequenceNumberColor: '#ffffff'
          },
          sequence: {
            diagramMarginX: 50,
            diagramMarginY: 30,
            actorMargin: 50,
            width: 150,
            height: 65,
            boxMargin: 10,
            boxTextMargin: 5,
            noteMargin: 10,
            messageMargin: 35,
            mirrorActors: true,
            bottomMarginAdj: 1,
            useMaxWidth: true,
            rightAngles: false,
            showSequenceNumbers: false,
            actorFontSize: 14,
            actorFontFamily: 'ui-sans-serif, system-ui, sans-serif',
            actorFontWeight: 600,
            noteFontSize: 12,
            noteFontFamily: 'ui-sans-serif, system-ui, sans-serif',
            noteFontWeight: 400,
            noteAlign: 'center',
            messageFontSize: 12,
            messageFontFamily: 'ui-sans-serif, system-ui, sans-serif',
            messageFontWeight: 400,
            wrap: true,
            wrapPadding: 10,
            labelBoxWidth: 50,
            labelBoxHeight: 20
          }
        });

        if (mermaidRef.current) {
          // 清空容器
          mermaidRef.current.innerHTML = '';
          
          // 创建一个临时的div来渲染图表
          const tempDiv = document.createElement('div');
          tempDiv.innerHTML = `<div class="mermaid">${chart}</div>`;
          
          // 使用 mermaid.render 方法渲染图表
          const { svg } = await mermaid.render(`${id}-${Date.now()}`, chart);
          
          // 将渲染的 SVG 插入到容器中
          mermaidRef.current.innerHTML = svg;

          // 修复垂直线样式 - 使其不穿过参与者框
          const svgElement = mermaidRef.current.querySelector('svg');
          if (svgElement) {
            // 设置SVG样式
            svgElement.style.maxWidth = '100%';
            svgElement.style.height = 'auto';
            
            // 添加自定义样式来修复垂直线
            const style = document.createElement('style');
            style.textContent = `
              .actor-line {
                stroke-dasharray: 5,5 !important;
                stroke-opacity: 0.6 !important;
              }
              .actor {
                filter: drop-shadow(0 4px 8px rgba(0, 0, 0, 0.3));
              }
              .messageText {
                fill: #ffffff !important;
                font-weight: 500 !important;
              }
              .labelText {
                fill: #ffffff !important;
                font-weight: 600 !important;
              }
              .loopText {
                fill: #ffffff !important;
              }
              .noteText {
                fill: #ffffff !important;
                font-weight: 500 !important;
              }
              /* 修复垂直线样式 */
              g.actor-line line {
                stroke-dasharray: 3,3 !important;
                stroke-opacity: 0.5 !important;
                stroke-width: 1.5 !important;
              }
              /* 确保参与者框在垂直线之上 */
              .actor {
                z-index: 10;
              }
              /* 调整消息箭头样式 */
              .messageLine0, .messageLine1 {
                stroke-width: 2 !important;
                stroke-opacity: 0.9 !important;
              }
              /* 调整返回消息样式 */
              .messageLine1 {
                stroke-dasharray: 4,4 !important;
              }
            `;
            svgElement.appendChild(style);

            // 查找并修改垂直线元素
            const lines = svgElement.querySelectorAll('line');
            lines.forEach(line => {
              const x1 = line.getAttribute('x1');
              const x2 = line.getAttribute('x2');
              const y1 = parseFloat(line.getAttribute('y1') || '0');
              const y2 = parseFloat(line.getAttribute('y2') || '0');
              
              // 如果是垂直线（x1 === x2 且线很长）
              if (x1 === x2 && Math.abs(y2 - y1) > 100) {
                line.setAttribute('stroke-dasharray', '3,3');
                line.setAttribute('stroke-opacity', '0.5');
                line.setAttribute('stroke-width', '1.5');
                line.classList.add('actor-line');
              }
            });
          }
        }
      } catch (error) {
        console.error('Mermaid rendering error:', error);
        // 如果渲染失败，显示错误信息
        if (mermaidRef.current) {
          mermaidRef.current.innerHTML = `
            <div class="text-white/60 text-center p-8">
              <p>图表渲染失败，请刷新页面重试</p>
              <p class="text-sm mt-2 text-white/40">错误: ${error.message}</p>
            </div>
          `;
        }
      }
    };

    // 延迟初始化以确保DOM完全加载
    const timer = setTimeout(() => {
      initializeMermaid();
    }, 100);

    return () => clearTimeout(timer);
  }, [chart, id]);

  return (
    <div 
      ref={mermaidRef} 
      className="mermaid-container w-full flex justify-center items-center bg-transparent"
      style={{ minHeight: '500px' }}
    />
  );
};

export default MermaidDiagram;